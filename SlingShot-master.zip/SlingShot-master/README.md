# SlingShot
a slingshot game
这是一个用html5 canvas做的一个移动端的小游戏

slingshot was build by HTML5-canvas on mobile stage.
Timer use requestAnimationFrame.

only support touch event.

view on:https://hx2heng.github.io/SlingShot/